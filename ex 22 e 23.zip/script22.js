
document.getElementById("paragrafo").addEventListener("dblclick", function() {
    this.style.display = "none";
});
