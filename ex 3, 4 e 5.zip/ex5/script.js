function calcularMedia() {
    const n1 = Number(document.getElementById("n1").value);
    const n2 = Number(document.getElementById("n2").value);
    const n3 = Number(document.getElementById("n3").value);
    const media = (n1 + n2 + n3) / 3;
    const msg = media >= 6 ? "Aprovado" : "Reprovado";
    document.getElementById("media").innerText = `Média: ${media.toFixed(2)} - ${msg}`;
}
