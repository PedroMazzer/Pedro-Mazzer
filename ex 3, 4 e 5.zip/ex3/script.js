let numero = 0;
function alterar(delta) {
    numero += delta;
    document.getElementById("valor").innerText = numero;
}
