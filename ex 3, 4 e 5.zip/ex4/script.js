const segredo = Math.floor(Math.random() * 11);
function adivinhar() {
    const chute = parseInt(document.getElementById("tentativa").value);
    const res = chute === segredo ? "Acertou!" : "Errou! O número era " + segredo;
    document.getElementById("resposta").innerText = res;
}
