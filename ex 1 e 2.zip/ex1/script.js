function verificarParImpar() {
    const num = parseInt(document.getElementById("num").value);
    const resultado = num % 2 === 0 ? "Par" : "Ímpar";
    document.getElementById("resultado").innerText = `O número é ${resultado}.`;
}
