function mostrarTabuada() {
    const n = parseInt(document.getElementById("numero").value);
    let lista = "";
    for (let i = 1; i <= 10; i++) {
        lista += `<li>${n} x ${i} = ${n * i}</li>`;
    }
    document.getElementById("tabuada").innerHTML = lista;
}
