document.getElementById("quizForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const resposta = document.querySelector('input[name="resposta"]:checked');
  if (resposta && resposta.value === "Brasília") {
    document.getElementById("resultado").innerText = "Correto!";
  } else {
    document.getElementById("resultado").innerText = "Incorreto.";
  }
});