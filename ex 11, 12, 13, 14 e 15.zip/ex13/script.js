function converter(tipo) {
  const valor = parseFloat(document.getElementById("valor").value);
  let resultado;
  if (tipo === 'C') {
    resultado = (valor - 32) * 5/9;
    document.getElementById("resultado").innerText = valor + "°F = " + resultado.toFixed(2) + "°C";
  } else {
    resultado = (valor * 9/5) + 32;
    document.getElementById("resultado").innerText = valor + "°C = " + resultado.toFixed(2) + "°F";
  }
}