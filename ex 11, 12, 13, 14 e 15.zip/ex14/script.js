function saudar() {
  const nome = document.getElementById("nome").value;
  alert("Olá " + nome + ". Seja bem-vindo(a)!");
}