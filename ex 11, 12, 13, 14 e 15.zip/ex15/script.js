let tempo = 0;
let intervalo;

function atualizarDisplay() {
  document.getElementById("display").innerText = tempo;
}

function iniciar() {
  if (!intervalo) {
    intervalo = setInterval(() => {
      tempo++;
      atualizarDisplay();
    }, 1000);
  }
}

function pausar() {
  clearInterval(intervalo);
  intervalo = null;
}

function zerar() {
  tempo = 0;
  atualizarDisplay();
  pausar();
}