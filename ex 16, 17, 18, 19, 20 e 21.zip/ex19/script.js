let cliques = 0;
document.getElementById("btnContador").addEventListener("click", () => {
  cliques++;
  document.getElementById("contador").innerText = cliques;
});