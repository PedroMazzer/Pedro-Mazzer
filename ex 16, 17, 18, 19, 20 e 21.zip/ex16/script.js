document.querySelectorAll('input[name="cor"]').forEach(radio => {
  radio.addEventListener("change", () => {
    document.body.style.backgroundColor = radio.value;
  });
});