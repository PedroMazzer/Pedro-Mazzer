document.getElementById("quiz").addEventListener("submit", function(e) {
  e.preventDefault();
  const resp = document.querySelector('input[name="resp"]:checked');
  const resultado = document.getElementById("resultado");
  resultado.innerText = resp && resp.value === "8" ? "Correto!" : "Incorreto.";
});