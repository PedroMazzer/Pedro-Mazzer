document.getElementById("inputTecla").addEventListener("keydown", function(e) {
  document.getElementById("teclaPressionada").innerText = e.key;
});