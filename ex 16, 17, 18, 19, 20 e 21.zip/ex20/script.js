const texto = document.getElementById("textoHover");
texto.addEventListener("mouseover", () => {
  texto.innerText = "Mouse está sobre o texto!";
});
texto.addEventListener("mouseout", () => {
  texto.innerText = "Passe o mouse aqui";
});