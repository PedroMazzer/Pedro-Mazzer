document.getElementById("btnCor").addEventListener("click", () => {
  const cores = ["red", "green", "blue", "yellow", "purple"];
  const corAleatoria = cores[Math.floor(Math.random() * cores.length)];
  document.getElementById("btnCor").style.backgroundColor = corAleatoria;
});