document.getElementById("mudarCor").addEventListener("click", () => {
  document.body.style.backgroundColor = "#a1c3ff";
});