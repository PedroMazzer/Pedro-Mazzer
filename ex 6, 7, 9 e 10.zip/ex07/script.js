document.querySelector("form").addEventListener("submit", function(event) {
  const inputs = document.querySelectorAll("input, textarea");
  for (let input of inputs) {
    if (!input.value) {
      alert("Preencha todos os campos!");
      event.preventDefault();
      return;
    }
  }
});